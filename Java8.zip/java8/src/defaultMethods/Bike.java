package defaultMethods;

public class Bike implements Vehicles{

	@Override
	public void drive()
	{
		System.out.println("diesel");
	}
	
}
