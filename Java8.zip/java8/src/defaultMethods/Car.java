package defaultMethods;



public class Car implements Vehicles{

  @Override
  public void drive()
     {
			System.out.println("petrol");
		}
	}


