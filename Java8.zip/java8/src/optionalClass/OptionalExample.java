package optionalClass;

import java.util.Optional;



public class OptionalExample {
public static Optional <String > getName ()
{ String name= "Krati";
return Optional.ofNullable(name);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String name= " ";
	Optional<String>optional=Optional.ofNullable(name);
		
		System.out.println(optional.isPresent());
		System.out.println(optional.get());
		System.out.println(optional.orElse("No value Present"));
		optional.orElseThrow();
		
		Optional<String>nameOptional=getName();
		System.out.println(nameOptional.orElse(null));
	}

}
