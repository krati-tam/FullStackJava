package functionalInterface;

import java.util.function.Consumer;

public class ConsumerClass {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Consumer<String> print= x->System.out.println(x);
	print.accept("Consumer Example");



		
	}

}
