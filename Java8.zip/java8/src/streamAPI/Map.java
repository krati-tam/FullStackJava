package streamAPI;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String>names=Arrays.asList("krati","kajal","kartik");
List<String>nameintoUpperList = new ArrayList<String>();


//before java 8
for(String name:names)
{
	nameintoUpperList.add(name.toUpperCase());
}
System.out.println(nameintoUpperList);

// using stream Map method
nameintoUpperList=names.stream().map(name->name.toUpperCase()).collect(Collectors.toList());
System.out.println(nameintoUpperList);

	}

}
