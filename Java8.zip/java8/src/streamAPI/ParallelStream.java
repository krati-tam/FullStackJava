package streamAPI;

import java.util.Arrays;
import java.util.List;


class Student 
{
	String name;
	int score;
	Student (String name,int score)
	{
		this.name=name;
		this.score=score;
	}
	public String getName()
	{
		return this.name;
	}
	public int getScore()
	{
		return this.score;
	}
}


public class ParallelStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Student>studentList=Arrays.asList(new Student("kratik", 11),new Student("krati", 12),new Student("kartik",45));
	
studentList.parallelStream().filter(s->s.getScore()>=20).forEach(stu->System.out.println(stu.getName()+" "+stu.getScore()));

	}

}
