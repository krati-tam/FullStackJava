package streamAPI;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Distinct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String>names=Arrays.asList("krati","kajal","krati","kartik");
		List<String>nameUniqueList  = names.stream().distinct().collect(Collectors.toList());

		System.out.println(nameUniqueList);
		nameUniqueList.stream().distinct().forEach(val->System.out.println(val));
	
		
		//count 
		long count =names.stream().distinct().count();
		System.out.println(count);
	
	//limit
		List<String>limitedList= names.stream().limit(2).collect(Collectors.toList());
		System.out.println(limitedList);
	
		//min
		List<Integer>numbersList =Arrays.asList(1,2,3,12,24,54,78);
		Optional <Integer>max=numbersList.stream().max((n1,n2)->{return n1.compareTo(n2);
		
		});
		System.out.println(max.get());
		
	}

}
