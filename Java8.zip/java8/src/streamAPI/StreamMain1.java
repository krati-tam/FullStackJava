package streamAPI;

import java.util.List;

import java.util.stream.Collectors;
public class StreamMain1 {
	public static void main(String[] args) {
	List<Integer>list1=List.of(2,3,5,7,8);

	List<Integer>newList=list1.stream().filter(i ->i%2 ==0).collect(Collectors.toList());
	System.out.println(newList);
	list1.stream().filter(i ->i%2 ==0).forEach(i->System.out.println(i));
}
}
