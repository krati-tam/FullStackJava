package java8;

@FunctionalInterface

interface lambda
{
	public void show();
}

 public class LambdaExp{
public static void main(String[] args) {
	 int a=5;
	 int b=4;
	 
	 /* lambda lambda= new lambda() {
		 public void show()
		 {
			 System.out.println(a+b);
		 };
		 lambda.show();
	 }*/
	 
	 
	lambda la=() ->{
		System.out.println(a+b);
	};
		la.show();
	}
			
}
	

